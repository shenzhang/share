/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class VariableEditorCtrl {
    private $scope;
    private datasourceSrv;
    private variableSrv;
    /** @ngInject **/
    constructor($scope: any, datasourceSrv: any, variableSrv: any, templateSrv: any);
}
